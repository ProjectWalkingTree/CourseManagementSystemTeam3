package com.example.coursemanage.Controller;



import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;


import com.example.coursemanage.Domain.Course;
import com.example.coursemanage.Service.CourseService;



@Controller
public class CourseController
{

	@Autowired
	private CourseService service;

	@GetMapping("/")
	public String home(Model m) 
	{
		List<Course> cs=service.getAllCourse();
		m.addAttribute("csi",cs);
		return "index";
	}
 
	@GetMapping("/add")
	public String addCourseForm() 
	{
		return "addcourse";
	}

	@PostMapping("/register")
	public String courseRegister(@ModelAttribute Course e, HttpSession session) 
	{
		System.out.println(e);
		service.addCourse(e);
		session.setAttribute("msg", "Course Added Sucessfully..");
		return "redirect:/";
	}

	@GetMapping("/edit/{id}")
	public String edit(@PathVariable int id, Model m) 
	{
		Course e = service.getCourseById(id);
		m.addAttribute("course", e);
		return "edit";
	}

//	@PostMapping("/update")
//	public String updateCourse(@ModelAttribute Course e, HttpSession session) 
//	{
//		service.updateCourse(e);
//		session.setAttribute("msg", "Course Data Update Sucessfully..");
//		return "redirect:/";
//	}
	
	

	@GetMapping("/delete/{id}")
	public String deleteCourse(@PathVariable int id, HttpSession session) 
	{

		service.deleteCourse(id);
		session.setAttribute("msg", "Course Data Delete Sucessfully..");
		return "redirect:/";
	}

	

}







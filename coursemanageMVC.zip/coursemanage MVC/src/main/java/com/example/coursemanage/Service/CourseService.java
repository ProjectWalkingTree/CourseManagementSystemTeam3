package com.example.coursemanage.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.example.coursemanage.Domain.Course;
import com.example.coursemanage.Repository.CourseRepository;


@Service
public class CourseService 
{

	@Autowired
	private CourseRepository repo;

	public void addCourse(Course e) 
	{
		repo.save(e);
	}

	public List<Course> getAllCourse() 
	{
		return repo.findAll();
	}

	public Course getCourseById(int id) 
	{
		Optional<Course> e = repo.findById(id);
		if (e.isPresent()) 
		{
			return e.get();
		}
		return null;
	}

	public void deleteCourse(int id) 
	{
		repo.deleteById(id);
	}

	

	

}
package com.example.coursemanage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoursemanageApplicationTests {

	@Test
	void contextLoads() {
	}

}
